# Python
This folder contains the **Core Python** codes along with some of the packages like **Numpy**, **Pandas** and **Matplotlib**.
