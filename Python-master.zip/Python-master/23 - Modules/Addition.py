#function 1
def add_two_numbers(num1 = 0,num2 = 0):
	print('Inside Addition')
	return num1+num2

#function 2
def add_three_numbers(num1 = 0,num2 = 0,num3 = 0):
	return num1+num2+num3

#variable 1
num_list = [1,2,3,4,5]

#variable 2
dict1 = {
    "Brand":"Bajaj",
    "model":"Pulsar",
    "year":2015,
    "cost":85000
}